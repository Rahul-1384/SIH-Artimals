// export const PF = "http://localhost:5000/images/";
// export const DeployedURL = "http://localhost:5000/api";

export const DeployedURL = "https://udhamini-api.azurewebsites.net/api";
export const PF = "https://udhamini-api.azurewebsites.net/images/";


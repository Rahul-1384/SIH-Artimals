// write a js function to upload an image to http://localhost:5000/api/upload
